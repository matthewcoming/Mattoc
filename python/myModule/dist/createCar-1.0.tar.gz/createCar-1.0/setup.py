from distutils.core import setup
setup(  name='createCar',
        version='1.0',
        author='Matthew Coming',
        author_email='coming.matthew@gmail.com',
        url='kipja.com'
        )

myModule, an example project to learn PEP257, distutils, and other pythonic
ideas.

myModule contains four files:
setup.py, which contains the myModuel metadata;
README.txt, which you are currently reading;
createCar.py, a pure python file that includes all that which is myModule; and
test_createCar.py, which contains unittest and nose framework tests.
